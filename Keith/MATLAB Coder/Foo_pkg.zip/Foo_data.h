/*
 * File: Foo_data.h
 *
 * MATLAB Coder version            : 5.5
 * C/C++ source code generated on  : 11-Dec-2022 19:50:08
 */

#ifndef FOO_DATA_H
#define FOO_DATA_H

/* Include Files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

/* Variable Declarations */
extern unsigned int state[625];
extern boolean_T isInitialized_Foo;

#endif
/*
 * File trailer for Foo_data.h
 *
 * [EOF]
 */
