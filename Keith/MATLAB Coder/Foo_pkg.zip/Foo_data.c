/*
 * File: Foo_data.c
 *
 * MATLAB Coder version            : 5.5
 * C/C++ source code generated on  : 11-Dec-2022 19:50:08
 */

/* Include Files */
#include "Foo_data.h"

/* Variable Definitions */
unsigned int state[625];

boolean_T isInitialized_Foo = false;

/*
 * File trailer for Foo_data.c
 *
 * [EOF]
 */
