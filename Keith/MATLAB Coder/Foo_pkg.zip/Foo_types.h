/*
 * File: Foo_types.h
 *
 * MATLAB Coder version            : 5.5
 * C/C++ source code generated on  : 11-Dec-2022 19:50:08
 */

#ifndef FOO_TYPES_H
#define FOO_TYPES_H

/* Include Files */
#include "rtwtypes.h"

/* Type Definitions */
#ifndef struct_emxArray_real_T
#define struct_emxArray_real_T
struct emxArray_real_T {
  double *data;
  int *size;
  int allocatedSize;
  int numDimensions;
  boolean_T canFreeData;
};
#endif /* struct_emxArray_real_T */
#ifndef typedef_emxArray_real_T
#define typedef_emxArray_real_T
typedef struct emxArray_real_T emxArray_real_T;
#endif /* typedef_emxArray_real_T */

#endif
/*
 * File trailer for Foo_types.h
 *
 * [EOF]
 */
