/*
 * File: Foo.c
 *
 * MATLAB Coder version            : 5.5
 * C/C++ source code generated on  : 11-Dec-2022 19:50:08
 */

/* Include Files */
#include "Foo.h"
#include "Foo_data.h"
#include "Foo_emxutil.h"
#include "Foo_initialize.h"
#include "Foo_types.h"
#include "rand.h"
#include <math.h>

/* Function Declarations */
static void times(emxArray_real_T *in1, const emxArray_real_T *in2);

/* Function Definitions */
/*
 * Arguments    : emxArray_real_T *in1
 *                const emxArray_real_T *in2
 * Return Type  : void
 */
static void times(emxArray_real_T *in1, const emxArray_real_T *in2)
{
  emxArray_real_T *b_in1;
  const double *in2_data;
  double *b_in1_data;
  double *in1_data;
  int aux_0_1;
  int aux_1_1;
  int b_loop_ub;
  int i;
  int i1;
  int loop_ub;
  int stride_0_0;
  int stride_0_1;
  int stride_1_0;
  int stride_1_1;
  in2_data = in2->data;
  in1_data = in1->data;
  emxInit_real_T(&b_in1, 2);
  i = b_in1->size[0] * b_in1->size[1];
  if (in2->size[0] == 1) {
    b_in1->size[0] = in1->size[0];
  } else {
    b_in1->size[0] = in2->size[0];
  }
  if (in2->size[1] == 1) {
    b_in1->size[1] = in1->size[1];
  } else {
    b_in1->size[1] = in2->size[1];
  }
  emxEnsureCapacity_real_T(b_in1, i);
  b_in1_data = b_in1->data;
  stride_0_0 = (in1->size[0] != 1);
  stride_0_1 = (in1->size[1] != 1);
  stride_1_0 = (in2->size[0] != 1);
  stride_1_1 = (in2->size[1] != 1);
  aux_0_1 = 0;
  aux_1_1 = 0;
  if (in2->size[1] == 1) {
    loop_ub = in1->size[1];
  } else {
    loop_ub = in2->size[1];
  }
  for (i = 0; i < loop_ub; i++) {
    i1 = in2->size[0];
    if (i1 == 1) {
      b_loop_ub = in1->size[0];
    } else {
      b_loop_ub = i1;
    }
    for (i1 = 0; i1 < b_loop_ub; i1++) {
      b_in1_data[i1 + b_in1->size[0] * i] =
          in1_data[i1 * stride_0_0 + in1->size[0] * aux_0_1] *
          in2_data[i1 * stride_1_0 + in2->size[0] * aux_1_1];
    }
    aux_1_1 += stride_1_1;
    aux_0_1 += stride_0_1;
  }
  i = in1->size[0] * in1->size[1];
  in1->size[0] = b_in1->size[0];
  in1->size[1] = b_in1->size[1];
  emxEnsureCapacity_real_T(in1, i);
  in1_data = in1->data;
  loop_ub = b_in1->size[1];
  for (i = 0; i < loop_ub; i++) {
    b_loop_ub = b_in1->size[0];
    for (i1 = 0; i1 < b_loop_ub; i1++) {
      in1_data[i1 + in1->size[0] * i] = b_in1_data[i1 + b_in1->size[0] * i];
    }
  }
  emxFree_real_T(&b_in1);
}

/*
 * Arguments    : double a
 *                double b
 *                double x
 *                double y
 *                emxArray_real_T *result
 * Return Type  : void
 */
void Foo(double a, double b, double x, double y, emxArray_real_T *result)
{
  emxArray_real_T *buff_2;
  double s_tmp;
  double *buff_2_data;
  double *result_data;
  int i;
  int k;
  if (!isInitialized_Foo) {
    Foo_initialize();
  }
  s_tmp = (b - a) + 1.0;
  b_rand(x, y, result);
  result_data = result->data;
  i = result->size[0] * result->size[1];
  for (k = 0; k < i; k++) {
    result_data[k] = a + floor(result_data[k] * s_tmp);
  }
  emxInit_real_T(&buff_2, 2);
  b_rand(x, y, buff_2);
  buff_2_data = buff_2->data;
  i = buff_2->size[0] * buff_2->size[1];
  for (k = 0; k < i; k++) {
    buff_2_data[k] = a + floor(buff_2_data[k] * s_tmp);
  }
  if ((result->size[0] == buff_2->size[0]) &&
      (result->size[1] == buff_2->size[1])) {
    k = result->size[0] * result->size[1];
    for (i = 0; i < k; i++) {
      result_data[i] *= buff_2_data[i];
    }
  } else {
    times(result, buff_2);
  }
  emxFree_real_T(&buff_2);
}

/*
 * File trailer for Foo.c
 *
 * [EOF]
 */
