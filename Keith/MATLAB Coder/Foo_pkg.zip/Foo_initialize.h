/*
 * File: Foo_initialize.h
 *
 * MATLAB Coder version            : 5.5
 * C/C++ source code generated on  : 11-Dec-2022 19:50:08
 */

#ifndef FOO_INITIALIZE_H
#define FOO_INITIALIZE_H

/* Include Files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
extern void Foo_initialize(void);

#ifdef __cplusplus
}
#endif

#endif
/*
 * File trailer for Foo_initialize.h
 *
 * [EOF]
 */
