/*
 * File: eml_rand_mt19937ar_stateful.h
 *
 * MATLAB Coder version            : 5.5
 * C/C++ source code generated on  : 11-Dec-2022 19:50:08
 */

#ifndef EML_RAND_MT19937AR_STATEFUL_H
#define EML_RAND_MT19937AR_STATEFUL_H

/* Include Files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
void c_eml_rand_mt19937ar_stateful_i(void);

#ifdef __cplusplus
}
#endif

#endif
/*
 * File trailer for eml_rand_mt19937ar_stateful.h
 *
 * [EOF]
 */
