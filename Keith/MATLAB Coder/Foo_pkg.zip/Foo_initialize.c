/*
 * File: Foo_initialize.c
 *
 * MATLAB Coder version            : 5.5
 * C/C++ source code generated on  : 11-Dec-2022 19:50:08
 */

/* Include Files */
#include "Foo_initialize.h"
#include "Foo_data.h"
#include "eml_rand_mt19937ar_stateful.h"

/* Function Definitions */
/*
 * Arguments    : void
 * Return Type  : void
 */
void Foo_initialize(void)
{
  c_eml_rand_mt19937ar_stateful_i();
  isInitialized_Foo = true;
}

/*
 * File trailer for Foo_initialize.c
 *
 * [EOF]
 */
