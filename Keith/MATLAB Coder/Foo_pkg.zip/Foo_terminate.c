/*
 * File: Foo_terminate.c
 *
 * MATLAB Coder version            : 5.5
 * C/C++ source code generated on  : 11-Dec-2022 19:50:08
 */

/* Include Files */
#include "Foo_terminate.h"
#include "Foo_data.h"

/* Function Definitions */
/*
 * Arguments    : void
 * Return Type  : void
 */
void Foo_terminate(void)
{
  isInitialized_Foo = false;
}

/*
 * File trailer for Foo_terminate.c
 *
 * [EOF]
 */
