/*
 * File: Foo.h
 *
 * MATLAB Coder version            : 5.5
 * C/C++ source code generated on  : 11-Dec-2022 19:50:08
 */

#ifndef FOO_H
#define FOO_H

/* Include Files */
#include "Foo_types.h"
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
extern void Foo(double a, double b, double x, double y,
                emxArray_real_T *result);

#ifdef __cplusplus
}
#endif

#endif
/*
 * File trailer for Foo.h
 *
 * [EOF]
 */
