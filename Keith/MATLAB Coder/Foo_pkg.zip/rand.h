/*
 * File: rand.h
 *
 * MATLAB Coder version            : 5.5
 * C/C++ source code generated on  : 11-Dec-2022 19:50:08
 */

#ifndef RAND_H
#define RAND_H

/* Include Files */
#include "Foo_types.h"
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
void b_rand(double varargin_1, double varargin_2, emxArray_real_T *r);

#ifdef __cplusplus
}
#endif

#endif
/*
 * File trailer for rand.h
 *
 * [EOF]
 */
